(function(){
  pagePrgoress('.page-progress');
})()
